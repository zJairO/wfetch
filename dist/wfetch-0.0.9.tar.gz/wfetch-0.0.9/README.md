# wfetch

![](https://repository-images.githubusercontent.com/428005882/405f6ef3-9fd9-4ab5-a901-f200fc12031f)

wfetch is a Minimal Windows system information tool written in Python 

## Installation
```bash
pip install wfetch
```
## Usage
```bash
wfetch
```
## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)

## Buy Me a Coffee
<a href="https://www.buymeacoffee.com/zjairo" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="41" width="174"></a>
